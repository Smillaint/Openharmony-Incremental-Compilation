/*
 * Copyright (c) 2022-2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/// <reference path="../typescript/Types.d.ts" />
export type uint8 = int;
export type int8 = int;
export type int16 = int;
export type int32 = int;
export type uint32 = int;
export type int64 = long;
export type uint64 = long;
export type float32 = float;
export type float64 = double;

export {};
declare global {
    export interface Number {
        toByte(): int;
        toShort(): int;
        toInt(): int;
        toLong(): long;
        toFloat(): float;
        toDouble(): double;
    }
}
Number.prototype.toByte = function () {
    return this as Number | 0 as number;
};

Number.prototype.toShort = function () {
    return this as Number | 0 as number;
};

Number.prototype.toInt = function () {
    return this as Number | 0 as number;
};

Number.prototype.toLong = function () {
    return this as Number | 0 as number;
};

Number.prototype.toFloat = function () {
    return this as number;
};

Number.prototype.toDouble = function () {
    return this as number;
};

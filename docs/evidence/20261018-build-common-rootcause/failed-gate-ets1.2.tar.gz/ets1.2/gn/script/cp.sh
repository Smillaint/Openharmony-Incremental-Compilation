#!/bin/bash

# Copyright (c) 2025 Huawei Device Co., Ltd.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

if [ $# -lt 2 ]; then
    echo "Error: cp requires at least 2 arguments (source and target)" >&2
    exit 1
fi

# The last argument is the destination, all preceding arguments are sources.
# Reject copying a file or directory onto itself.
dest="${!#}"
i=1
while [ "$i" -lt "$#" ]; do
    src="${!i}"
    if [ "$src" = "$dest" ]; then
        echo "Error: source and target must not be the same path ($src)" >&2
        exit 1
    fi
    i=$((i + 1))
done

cp "$@"
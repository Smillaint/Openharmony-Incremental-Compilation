/*
 * Copyright (c) 2022-2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { int32, float64toInt32 } from '@koalaui/common';

export type ResourceId = int32;

interface ResourceInfo {
    resource: object | null | undefined;
    holdersCount: int32;
}

export interface Disposable {
    dispose(): void;
}

export class ResourceHolder {
    private static nextResourceId: ResourceId = 100;
    private resources: Map<ResourceId, ResourceInfo> = new Map<ResourceId, ResourceInfo>();
    private static _instance: ResourceHolder | undefined = undefined;
    private static disposables = new Array<Disposable>();
    private static disposablesSize = 0;

    static instance(): ResourceHolder {
        if (ResourceHolder._instance === undefined || ResourceHolder._instance === null) {
            ResourceHolder._instance = new ResourceHolder();
        }
        return ResourceHolder._instance!;
    }

    public hold(resourceId: ResourceId) {
        if (!this.resources.has(resourceId)) throw new Error(`Resource ${resourceId} does not exists, can not hold`);
        this.resources.get(resourceId)!.holdersCount++;
    }

    public release(resourceId: ResourceId) {
        if (!this.resources.has(resourceId)) throw new Error(`Resource ${resourceId} does not exists, can not release`);
        const resource = this.resources.get(resourceId)!;
        resource.holdersCount--;
        if (resource.holdersCount <= 0) this.resources.delete(resourceId);
    }

    public registerAndHold(resource: object | null | undefined): ResourceId {
        const resourceId = ResourceHolder.nextResourceId++;
        this.resources.set(resourceId, {
            resource: resource,
            holdersCount: 1,
        });
        return resourceId;
    }

    public get(resourceId: ResourceId): object | null | undefined {
        if (!this.resources.has(resourceId)) throw new Error(`Resource ${resourceId} does not exists`);
        return this.resources.get(resourceId)!.resource;
    }

    public has(resourceId: ResourceId): boolean {
        return this.resources.has(resourceId);
    }

    static register(resource: Disposable) {
        if (ResourceHolder.disposablesSize < ResourceHolder.disposables.length) {
            ResourceHolder.disposables[ResourceHolder.disposablesSize] = resource;
        } else {
            ResourceHolder.disposables.push(resource);
        }
        ResourceHolder.disposablesSize++;
    }

    static unregister(resource: Disposable) {
        const index = float64toInt32(ResourceHolder.disposables.indexOf(resource));
        if (index !== -1 && index < ResourceHolder.disposablesSize) {
            if (index !== ResourceHolder.disposablesSize - 1) {
                ResourceHolder.disposables[index] = ResourceHolder.disposables[ResourceHolder.disposablesSize - 1];
            }
            ResourceHolder.disposablesSize--;
        }
    }

    static disposeAll() {
        for (let i = 0; i < ResourceHolder.disposablesSize; ++i) {
            ResourceHolder.disposables[i].dispose();
        }
        ResourceHolder.disposablesSize = 0;
    }

    static compactDisposables() {
        ResourceHolder.disposables = ResourceHolder.disposables.slice(0, ResourceHolder.disposablesSize);
    }
}

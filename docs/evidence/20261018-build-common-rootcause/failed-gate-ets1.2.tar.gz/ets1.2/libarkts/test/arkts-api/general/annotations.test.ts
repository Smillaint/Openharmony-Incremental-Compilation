/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import * as util from "../../test-util"
import * as arkts from "../../../src/arkts-api"
import { suite, test, assert } from "@koalaui/harness"

suite(util.basename(__filename), () => {
    test("annotated-function-1", function() {
        util.initConfig()

        const sample_in =
        `
        @annotation1
        @annotation2
        function foo() {}
        `

        let script = arkts.createETSModuleFromSource(
            sample_in,
            arkts.Es2pandaContextState.ES2PANDA_STATE_PARSED
        )

        const annotations = arkts.getAnnotations(script.statements[0])

        const names = annotations.map((annot) => {
            if (annot.expr === undefined) {
                throw new Error('annotation expression is undefined')
            }
            if (!arkts.isIdentifier(annot.expr)) {
                throw new Error('annotation expected to be Identifier')
            }
            return annot.expr.name
        })

        assert.equal(names.join(', '), 'annotation1, annotation2')

        arkts.arktsGlobal.compilerContext?.destroy();
        arkts.arktsGlobal.configObj?.destroy();
    })
})

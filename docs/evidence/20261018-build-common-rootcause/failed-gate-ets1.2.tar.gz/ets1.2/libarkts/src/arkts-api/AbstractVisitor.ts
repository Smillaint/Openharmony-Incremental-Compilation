/*
 * Copyright (c) 2022-2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { AstNode } from './peers/AstNode';
import { visitEachChild } from './visitor';
import { Program } from '../../generated';

export interface VisitorOptions {
    program?: Program;
}

export abstract class AbstractVisitor {
    public program?: Program;

    constructor(options?: VisitorOptions) {
        this.program = options?.program;
    }

    indentation = 0;

    withIndentation<T>(exec: () => T): T {
        this.indentation++;
        const result = exec();
        this.indentation--;
        return result;
    }

    process(node: AstNode, options?: any): AstNode {
        return this.visitor(node, options);
    }

    init(): void {}

    reset(): void {
        this.indentation = 0;
    }

    abstract visitor(node: AstNode, options?: any): AstNode;

    visitEachChild(node: AstNode, options?: any): AstNode {
        return this.withIndentation((): AstNode => visitEachChild(node, (it): AstNode => this.visitor(it, options)));
    }
}

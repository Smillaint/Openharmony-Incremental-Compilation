/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { KNativePointer } from '@koalaui/interop';
import { ObjectExpression, Expression } from '../../../generated';
import { isSameNativeObject } from '../peers/ArktsObject';
import { updateNodeByNode } from '../utilities/private';
import { Es2pandaAstNodeType } from '../../../generated/Es2pandaEnums';

export function createObjectExpression(
    properties: readonly Expression[],
    preferredReturnType?: KNativePointer
): ObjectExpression {
    const result = ObjectExpression.createObjectExpression(
        Es2pandaAstNodeType.AST_NODE_TYPE_OBJECT_EXPRESSION,
        properties,
        false // Improve: provide trailingComma value from native module through ObjectExpression?
    );
    if (preferredReturnType) {
        result.setPreferredTypePointer(preferredReturnType);
    }
    return result;
}

export function updateObjectExpression(
    original: ObjectExpression,
    properties: readonly Expression[],
    preferredReturnType?: KNativePointer
): ObjectExpression {
    if (
        isSameNativeObject(properties, original.properties) &&
        preferredReturnType === original.getPreferredTypePointer()
    ) {
        return original;
    }
    return updateNodeByNode(createObjectExpression(properties, preferredReturnType), original);
}

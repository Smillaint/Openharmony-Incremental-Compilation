/*
 * Copyright (c) 2026 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Polyfills for Node 14 compatibility
// Required by @idlizer/arktscgen which uses .at() and .replaceAll() (Node 16.9+)

if (!Array.prototype.at) {
    Object.defineProperty(Array.prototype, 'at', {
        value: function(index) {
            const len = this.length;
            const i = index >= 0 ? index : len + index;
            return i >= 0 && i < len ? this[i] : undefined;
        },
        writable: true,
        enumerable: false,
        configurable: true
    });
}
if (!String.prototype.at) {
    Object.defineProperty(String.prototype, 'at', {
        value: function(index) {
            const len = this.length;
            const i = index >= 0 ? index : len + index;
            return i >= 0 && i < len ? this[i] : undefined;
        },
        writable: true,
        enumerable: false,
        configurable: true
    });
}
if (!String.prototype.replaceAll) {
    Object.defineProperty(String.prototype, 'replaceAll', {
        value: function(pattern, replacement) {
            if (!pattern) {
                throw new TypeError('replaceAll must be called with a non-empty pattern');
            }
            if (pattern instanceof String) {
                pattern = new RegExp(RegExp.escape(pattern), 'g')
            }
            if (pattern instanceof RegExp) {
                if (!pattern.global) {
                    throw new TypeError('replaceAll must be called with a global RegExp');
                }
                return this.replace(pattern, replacement);
            }
            return this.split(pattern).join(replacement);
        },
        writable: true,
        enumerable: false,
        configurable: true
    });
}
